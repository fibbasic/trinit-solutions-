TRINIT SOLUTIONS WEBSITE

Files:
- index.html — complete website
- style.css — responsive styling
- script.js — mobile menu + current year

HOW TO USE:
1. Upload all three files to an AI website builder that accepts HTML/CSS/JS, or to a static host.
2. The WhatsApp buttons already use Trinit Solutions' Nigerian WhatsApp number: 0803 712 7257.
3. Replace the three project placeholders with real installation photos when available.
4. Add the actual customer testimonials later; the current page only displays the supplied 4.6 rating and a general quote.

No product prices have been invented. System cards use "Request Quote".

PHOTO NOTE:
The hero and project gallery use free-to-use Unsplash photos from Nelspruit, South Africa. They are clearly presented as reference imagery, not as Trinit Solutions projects. Replace them with Trinit's own project photos when available.
