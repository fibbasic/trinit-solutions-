const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector("#main-nav");
if (menuToggle) {
  menuToggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", open);
  });
}
document.querySelectorAll("#main-nav a").forEach(link => {
  link.addEventListener("click", () => nav.classList.remove("open"));
});
document.getElementById("year").textContent = new Date().getFullYear();
